# Test Infrastructure Specification: FireDetection_Classification

## 1. Overview & Strategy
This test suite provides opaque-box verification for the fire and smoke classification system defined in `PROJECT.md` and `issues/ISSUE-01` through `ISSUE-06`. It validates interface contracts, mathematical and structural invariants, safety constraints (Fire Recall $\ge 90\%$), dual-gate ambient rejection ($\max(P) < 0.70$), and end-to-end pipeline execution without requiring external network access or downloading full HuggingFace datasets.

## 2. Directory Layout
```
tests/
├── conftest.py                   # Pytest fixtures, synthetic image generators, mock datasets
├── test_runner.py                # Standalone test orchestrator and reporter
├── unit/                         # Unit tests per interface contract
│   ├── __init__.py
│   ├── test_pipeline.py          # Data ingestion, corrupt filtering, pHash, DataLoader
│   ├── test_features.py          # RGB/HSV histograms, color moments, texture/Sobel descriptors
│   ├── test_resnet.py            # ResNet18 transfer backbone, freezing, weighted loss
│   ├── test_vit.py               # DeiT-Tiny ViT backbone, block freezing, training loop
│   ├── test_calibrate.py         # Decision threshold calibration & CPU benchmark
│   └── test_inference.py         # FireClassifier dual-gating & CLI interface
└── e2e/                          # Multi-tier end-to-end integration suites
    ├── __init__.py
    ├── test_tier1_features.py    # F1-F13 feature isolation verification
    ├── test_tier2_boundaries.py  # Edge cases, empty inputs, extreme thresholds, corruption
    ├── test_tier3_combinations.py# Subsystem coupling (pHash+Collation, Features+LGBM, Calib+Gating)
    └── test_tier4_workloads.py   # Full surveillance stream simulation and batch processing
```

## 3. Test Suites & Tier Mapping

### 3.1 Unit Test Suite (`tests/unit/`)
- `test_pipeline.py`: Validates `compute_phash`, `hamming_distance`, `get_eval_transforms`, `FireSmokeDataset`, and `create_dataloader`.
- `test_features.py`: Validates `extract_color_histogram` (96 features), `extract_color_moments` (9/18 features), `extract_texture_features`, and `extract_all_features`.
- `test_resnet.py`: Validates `build_resnet18`, layer freeze scheme (`conv1`, `bn1`, `layer1` frozen), and loss weighting ($w_{\text{fire}}=2.0, w_{\text{smoke}}=1.0$).
- `test_vit.py`: Validates `build_deit_tiny`, parameter freezing (`patch_embed`, `blocks[:6]`), and forward pass.
- `test_calibrate.py`: Validates `calibrate_threshold` on $\theta \in [0.10, 0.90]$, recall enforcement ($\ge 0.90$), and `benchmark_model_cpu`.
- `test_inference.py`: Validates `FireClassifier` dual-gate logic (Gate 1 ambient rejection at $\max(P) < \tau$, Gate 2 hazard classification at $P_{\text{fire}} \ge \theta^*$).

### 3.2 Tier 1: Feature Coverage (`tests/e2e/test_tier1_features.py`)
Isolates and validates features F1 through F13:
- **F1 (Dataset Ingestion)**: Split resolution, corruption filtering.
- **F2 (pHash Deduplication)**: Exact and near-duplicate pruning ($d_H \le 4$).
- **F3 (Evaluation Preprocessing)**: 224x224 LANCZOS, ImageNet normalization, zero data leakage.
- **F4 (PyTorch DataLoader)**: Batch collation, tensor shapes `(B, 3, 224, 224)`.
- **F5 (Classical Feature Extraction)**: Color and texture feature vectors.
- **F6 (Tier 1 LightGBM)**: Training, prediction, class weight penalization.
- **F7 (Tier 2 ResNet18 Backbone)**: Custom head `(Dropout(0.3) + Linear(512, 2))` and layer freezing.
- **F8 (Tier 2 Optimization Engine)**: Loss formulation with $w=[2.0, 1.0]$.
- **F9 (Tier 3 DeiT-Tiny ViT)**: Layer freezing `blocks[:6]` and attention head output.
- **F10 (Calibrated Threshold Sweep)**: Sweep over $[0.10, 0.90]$, safety enforcement.
- **F11 (CPU Latency & Champion Selection)**: Benchmark timing and champion config export.
- **F12 (Dual-Gating Inference Engine)**: Gate 1 ambient rejection, Gate 2 fire/smoke determination.
- **F13 (Production CLI & JSON Output)**: CLI invocation and JSON schema compliance.

### 3.3 Tier 2: Boundary & Corner Cases (`tests/e2e/test_tier2_boundaries.py`)
- Corrupted image stubs (truncated files, random binary noise, 0-byte files).
- Dimension extremes (1x1 pixels, 4096x4096 ultra-high-res, non-square ratios 1920x100).
- Extreme color spaces (single channel grayscale, 4-channel RGBA, palette images).
- Decision threshold limits ($\theta = 0.10, \theta = 0.90$).
- Ambient gate boundaries ($\max(P) = 0.699$ vs $\max(P) = 0.701$).
- Uniform/flat color frames (pure black `(0,0,0)`, pure white `(255,255,255)`).

### 3.4 Tier 3: Pairwise Combinations & Subsystem Interactions (`tests/e2e/test_tier3_combinations.py`)
- **pHash Dedup + DataLoader**: Ensures duplicate dropping preserves indexing, metadata alignment, and batch collation.
- **Feature Extraction + LightGBM**: Full pipeline from PIL Image $\rightarrow$ 1D feature vector $\rightarrow$ LightGBM probability outputs.
- **Calibration + Dual-Gate Inference**: Feeds calibrated $\theta^*$ into `FireClassifier` and validates boundary behavior.
- **Model Checkpointing + Inference Reloading**: Validates model export followed by instantiation in `FireClassifier`.

### 3.5 Tier 4: Real-World Application Workloads (`tests/e2e/test_tier4_workloads.py`)
- Simulated surveillance video stream (sequence of ambient, smoke emergence, active fire frames).
- Batch ingestion directory processing with mixed formats (`.png`, `.jpg`, `.jpeg`).
- JSON output report verification against production schema.
- Latency budget verification ($< 500$ ms/frame on CPU).

## 4. Synthetic Fixture Strategy (`tests/conftest.py`)
All tests operate on synthetic in-memory or temporary disk artifacts generated deterministically:
- `synthetic_fire_image`: Red/orange high-intensity gradient with localized bright spots.
- `synthetic_smoke_image`: Gray/whitish diffuse gaussian-like noise.
- `synthetic_ambient_image`: Uniform natural green/blue scenery pattern.
- `synthetic_corrupted_file`: Truncated bytes and invalid headers.
- `synthetic_duplicate_pair`: Identical image and near-identical image with minor pixel perturbations ($d_H \le 4$).
- `mock_dataset_dir`: Synthetic `train`, `validation`, and `test` directories matching HF structure.

## 5. Progressive Testability
During milestone execution (M1 through M6), tests dynamically detect implemented modules via `pytest.importorskip` or fallback runners. When a component is unimplemented, tests register as `SKIPPED` rather than fatal errors. Once implemented, tests run strict assertion verification.

## 6. Execution Commands
```bash
# Run via test runner with formatted summary
python3 tests/test_runner.py

# Run via pytest with detailed verbosity
pytest -v tests/

# Run specific tiers
pytest -v tests/e2e/test_tier1_features.py
pytest -v tests/e2e/test_tier2_boundaries.py
pytest -v tests/e2e/test_tier3_combinations.py
pytest -v tests/e2e/test_tier4_workloads.py
```
