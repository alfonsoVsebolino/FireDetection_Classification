# Notebook Review: Unstructured EDA & Feature Engineering

## 1. Pipeline Overview
```mermaid
flowchart TD
    A["HF Repo: Vertex-Test/FireSmokeDataset"] --> B("Ingest Splits: Train/Valid/Test")
    B --> C{"Data Quality Checks"}
    C --> |"Corrupted (RGB load fail)"| D["Drop"]
    C --> |"Duplicates (pHash dist <= 4)"| D["Drop"]
    C --> |"Valid"| E("Clean Dataset")
    E --> F["Resize: 224x224 LANCZOS"]
    F --> G{"Class Balancing"}
    G --> |"Minority Deficit"| H("Generate Synthetic via Augment")
    G --> |"Majority"| I("Pass-through")
    H --> J["concatenate_datasets"]
    I --> J
    J --> K["ds_final: Handoff"]
```

---

## 2. Execution Phases & Granular Parameters

### Phase 1: Ingestion
- **Source** → `Vertex-Test/FireSmokeDataset` (via `snapshot_download`)
- **Structure** → Extracted `.txt` labels mapped to `.jpg`/etc.
- **Classes** → `[0: fire, 1: smoke]`
- **Format** → HuggingFace `DatasetDict` (`train`, `validation`, `test`)

### Phase 2: Exploratory Data Analysis (EDA)
- **Visualizations**:
  - Class distribution (% and absolute).
  - W vs H scatter plot.
  - RGB Pixel Intensity (20-image density sample).
  - Aspect Ratio (W/H) vs Square (1.0).

### Phase 3: Data Quality Checks
- **Corruption Check** → Convert to `RGB` & attempt `.load()`.
- **Deduplication** → Perceptual Hashing (`imagehash.phash`).
  - **Threshold** → Hamming distance `<= 4`.
  - **Action** → Flag second item (`idx2`) of duplicate pair for removal.

```python
# pHash logic for near-duplicate detection
distance = h1 - h2
if distance <= 4:
    duplicate_pairs.append((idx1, idx2, distance))
    flagged_duplicates.add(idx2)
```

### Phase 4: Cleaning
- **Filter** → Exclude corrupted + duplicates using `train_data.select(valid_indices)`.
- **Resizing**:
  - **Algorithm** → `Image.Resampling.LANCZOS`
  - **Target dims** → `224x224`
  - **Format enforce** → `RGB`

### Phase 5: Augmentation & Class Balancing
- **Goal** → Equalize minority class counts to match majority class max (`target_count = max(label_counts.values())`).
- **Pipeline Parameters (PIL)**:
  - Horizontal Flip → 50% prob
  - Rotation → `[-15°, +15°]` (BICUBIC resample, no expansion)
  - Brightness → `[0.8x, 1.2x]` 
  - Contrast → `[0.8x, 1.2x]`
  - Gaussian Blur → 30% prob, radius `[0.0, 1.5]`

```python
# Augmentation pipeline application
for label, count in label_counts.items():
    needed = target_count - count
    if needed > 0:
        source_imgs = class_images[label]
        for i in range(needed):
            base_img = random.choice(source_imgs)
            aug_img = augment_image(base_img)
            augmented_data['image'].append(aug_img)
            augmented_data['label'].append(label)

# Critical Fix: Supplying schema features during merge
ds_new_samples = Dataset.from_dict(augmented_data, features=ds_clean.features)
ds_augmented = concatenate_datasets([ds_clean, ds_new_samples])
```

### Phase 6: Handoff
- **Output** → `ds_final` (100% 224x224, balanced classes)
- **Downstream Prep**:
  - Provided constants for PyTorch normalization during collation/training.
  - `IMAGENET_MEAN` → `[0.485, 0.456, 0.406]`
  - `IMAGENET_STD` → `[0.229, 0.224, 0.225]`
