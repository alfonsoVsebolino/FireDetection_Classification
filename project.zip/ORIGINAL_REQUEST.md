# Original User Request

## 2026-09-12T14:19:09Z

Implement modular, production-ready Python codebase under `src/` satisfying all 6 atomic specification tickets in `issues/` (`ISSUE-01` through `ISSUE-06`) for fire and smoke classification, multi-tier model benchmarking, safety-first champion selection, and real-world image ingestion.

Working directory: /home/alfonsovsebolino/Documents/CSELEC1-ML/EDA/FireDetection_Classification
Integrity mode: benchmark

## Requirements

### R1. Evaluation Split Data Pipeline (`ISSUE-01`)
Implement `src/data/pipeline.py` to ingest, clean (drop corrupt samples & deduplicate via pHash Hamming distance <= 4), and resize (224x224 RGB via LANCZOS) `validation` and `test` splits from HuggingFace dataset `Vertex-Test/FireSmokeDataset`. Guarantee zero data leakage (strictly zero synthetic balancing or augmentations on evaluation splits) and expose PyTorch `DataLoader` collation with ImageNet normalization (`mean=[0.485, 0.456, 0.406]`, `std=[0.229, 0.224, 0.225]`).

### R2. Tri-Tier Model Suite (`ISSUE-02`, `ISSUE-03`, `ISSUE-04`)
- **Tier 1 (Classical Feature Baseline)**: Implement `src/features/extract.py` (RGB/HSV 16-bin color histograms, color moments, texture/Sobel descriptors) and `src/models/train_lightgbm.py` using `LightGBMClassifier` with class weighting.
- **Tier 2 (CNN Transfer Anchor)**: Implement `src/models/train_resnet.py` using `torchvision.models.resnet18` with custom dropout + linear head and weighted CrossEntropy loss ($w_{\text{fire}}=2.0, w_{\text{smoke}}=1.0$) to penalize False Negatives.
- **Tier 3 (Vision Transformer)**: Implement `src/models/train_vit.py` using `deit_tiny_patch16_224` via `timm` with frozen initial blocks, fine-tuned upper blocks, and weighted loss.

### R3. Evaluation & Champion Selection Protocol (`ISSUE-05`)
Implement `src/evaluate/benchmark.py` and `src/evaluate/calibrate.py`:
- Sweep validation decision threshold $\theta \in [0.10, 0.90]$ to calibrate $\theta^*$ guaranteeing Fire Recall >= 90%.
- Evaluate all three tiers on the unaugmented `test` split (Confusion Matrix, Fire Recall, Precision, Macro F1, CPU latency ms/sample).
- Enforce Champion Selection Policy: Disqualify models with Fire Recall < 0.90; crown the model with the lowest CPU inference latency as Champion. Export weights and `champion_config.json`.

### R4. Real-World Ingestion CLI & API (`ISSUE-06`)
Implement `src/inference.py`:
- `FireClassifier` class supporting single image path, batch directory, or NumPy/PIL/OpenCV frames.
- Image preprocessing matching training parity (RGB conversion, 224x224 LANCZOS resize, ImageNet normalization).
- Dual decision gating:
  - Gate 1: If $\max(P_{\text{fire}}, P_{\text{smoke}}) < 0.70 \rightarrow$ label as `ambient_frame` (`hazard_detected: false`).
  - Gate 2: If $P_{\text{fire}} \ge \theta^* \rightarrow$ `fire`; else `smoke` (`hazard_detected: true`).
- CLI interface accepting `--input`, `--threshold`, `--output-json`, `--save-overlay`.

### R5. Execution Constraints
- Do NOT execute code cells inside `unstructured_eda_and_feature_engineering.ipynb`.
- Primary focus is modular code creation under `src/` conforming to `CONTEXT.md`.

## Acceptance Criteria

### Code Quality & Static Validation
- [ ] All source files under `src/` compile cleanly without syntax errors: `python3 -m py_compile src/**/*.py`.
- [ ] Proper package structure with `__init__.py` files across `src/data`, `src/features`, `src/models`, `src/evaluate`.
- [ ] Forward passes of ResNet18 and DeiT-Tiny execute successfully on dummy tensor `(1, 3, 224, 224)` on CPU.
- [ ] Preprocessing and inference in `src/inference.py` execute successfully on dummy 224x224 RGB PIL image, validating both `ambient_frame` rejection and hazard prediction branches.
- [ ] Notebook `unstructured_eda_and_feature_engineering.ipynb` remains unmodified.
