# Teaching Mission: Fire & Smoke Machine Learning Lifecycle

## 1. The Mission
Master the architectural rationale, inner workings, model selection dynamics, and operational hyperparameter landscape of the modular fire and smoke classification workspace.

## 2. Why This Matters
Real-world hazard classification operates under asymmetric penalties: a false negative (missed fire) is catastrophic, while an ambient non-hazard frame must be gracefully rejected without false alarms. Understanding how each modular phase in `src/`—from pHash deduplication to dual-gate confidence rejection—contributes to safety-first deployment transforms machine learning theory into production reliability.

## 3. Core Learning Objectives
- **Architecture Understanding**: Map why each component in `src/` exists and how data flows through the lifecycle without evaluation leakage.
- **Model Selection Wisdom**: Contrast classical gradient boosted trees (LightGBM on handcrafted moments/histograms) with deep convolutional anchors (ResNet18) and attention-based Vision Transformers (DeiT-Tiny).
- **Hyperparameter Mechanics**: Understand exactly what knobs can be tuned (`batch_size`, `lr`, `weight_decay`, `fire_weight`, `accum_steps`, `min_recall`, `tau`), their defaults, and their concrete mathematical impact on model convergence and recall.
- **Serving Dynamics**: Understand how dual-gate inference rejects ambient surveillance frames before hazard decision boundaries are applied.
