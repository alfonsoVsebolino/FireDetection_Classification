# Fire & Smoke Classification Context

Classification pipeline for detecting active fire and smoke phenomena from unstructured imagery, with confidence-gated rejection for ambient real-world feeds.

## Language

**Fire**:
Thermal combustion event presenting active flame signatures in visual spectrum imagery (target class 0).
_Avoid_: Blaze, flame, burning

**Smoke**:
Particulate emissions and plume aerosols resulting from combustion (target class 1).
_Avoid_: Vapor, haze, steam, exhaust

**Ambient Frame**:
An unclassified real-world scene lacking active fire or smoke, rejected via inference confidence gating ($\max(P) < \tau$).
_Avoid_: Background, neutral, normal, negative sample

**Champion Model**:
The candidate architecture satisfying safety constraints (Fire Recall $\ge 90\%$) with minimum CPU inference latency.
_Avoid_: Best model, final model, top model

**False Negative (FN)**:
A critical classification failure where a true fire frame is misclassified as smoke or ambient.
_Avoid_: Type II error, missed detection
