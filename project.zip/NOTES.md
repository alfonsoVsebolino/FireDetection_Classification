# User Preferences & Working Notes

## Format & Location Preferences
- **Location**: `reference/ml-lifecycle.html` conforming to `/teach` workspace structure.
- **Separation of Concerns**: Clean separation into `assets/style.css`, `assets/app.js`, and `reference/ml-lifecycle.html`.
- **Navigation**: Multi-step Stepper Wizard with persistent/collapsible Sidebar Table of Contents for dynamic pagination.

## Pedagogical & Presentation Preferences
- **Hyperparameter Presentation**: Dedicated Hyperparameter Inspector Cards per lifecycle phase with Default, Tuning Range, and Physical/Mathematical Effect.
- **Interactive Tools**: In-browser interactive threshold slider ($\theta^*$) and dual-gate simulator ($\tau$ ambient rejection) for experiential understanding.
- **Tone**: Dense, engineering-grade tutorial and reference guide detailing the "Why" behind architectural decisions, safety constraints (Fire Recall $\ge 90\%$), and CPU/GPU trade-offs.
